package com.feha.ai.settings.storage

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.core.DataStore
import com.feha.ai.settings.model.AppLanguage
import com.feha.ai.settings.model.FEMALE_VOICES
import com.feha.ai.settings.model.MAX_SPEECH_SPEED
import com.feha.ai.settings.model.NovaSettings
import com.feha.ai.settings.model.Personality
import com.feha.ai.settings.model.ThemeMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class NovaPreferencesTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private fun openStore(scope: CoroutineScope, file: File): DataStore<Preferences> =
        PreferenceDataStoreFactory.create(scope = scope, produceFile = { file })

    @Test
    fun emptyStoreReturnsDefaults() = runBlocking {
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        try {
            val prefs = NovaPreferences(openStore(scope, File(tmp.root, "empty.preferences_pb")))
            assertEquals(NovaSettings(), prefs.settings.first())
        } finally {
            scope.cancel()
        }
    }

    @Test
    fun settingsSurviveRestart() = runBlocking {
        val file = File(tmp.root, "restart.preferences_pb")
        val expected = NovaSettings(
            assistantName = "FEHA Helper",
            username = "Rafiq",
            themeMode = ThemeMode.DARK,
            personality = Personality.TEACHER,
            language = AppLanguage.BENGALI,
            voiceName = FEMALE_VOICES[1].id,
            speechSpeed = 1.5f,
            voiceVolume = 0.4f
        )

        val firstScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        try {
            NovaPreferences(openStore(firstScope, file)).update { expected }
        } finally {
            firstScope.cancel()
        }

        // A new DataStore on the same file simulates an app restart.
        val secondScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        try {
            val reloaded = NovaPreferences(openStore(secondScope, file)).settings.first()
            assertEquals(expected, reloaded)
        } finally {
            secondScope.cancel()
        }
    }

    @Test
    fun invalidStoredValuesFallBackSafely() = runBlocking {
        val file = File(tmp.root, "invalid.preferences_pb")
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        try {
            val store = openStore(scope, file)
            store.edit { prefs ->
                prefs[stringPreferencesKey("language")] = "KLINGON"
                prefs[stringPreferencesKey("theme_mode")] = "PURPLE"
                prefs[floatPreferencesKey("speech_speed")] = 9f
            }
            val s = NovaPreferences(store).settings.first()
            assertEquals(AppLanguage.AUTO, s.language)
            assertEquals(ThemeMode.SYSTEM, s.themeMode)
            assertEquals(MAX_SPEECH_SPEED, s.speechSpeed, 0.0001f)
        } finally {
            scope.cancel()
        }
    }
}
