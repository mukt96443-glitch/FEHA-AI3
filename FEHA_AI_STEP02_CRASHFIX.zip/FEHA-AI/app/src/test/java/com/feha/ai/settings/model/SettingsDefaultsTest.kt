package com.feha.ai.settings.model

import com.feha.ai.core.AssistantBrand
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SettingsDefaultsTest {

    @Test
    fun brandValuesMatchSpec() {
        assertEquals("FEHA", AssistantBrand.NAME)
        assertEquals("FEHA AI", AssistantBrand.FULL_NAME)
    }

    @Test
    fun defaultSettingsMatchSpec() {
        val s = NovaSettings()
        assertEquals("FEHA", s.assistantName)
        assertEquals("", s.username)
        assertEquals(ThemeMode.SYSTEM, s.themeMode)
        assertEquals(Personality.NORMAL, s.personality)
        assertEquals(AppLanguage.AUTO, s.language)
        assertEquals(DEFAULT_VOICE_NAME, s.voiceName)
        assertEquals(DEFAULT_SPEECH_SPEED, s.speechSpeed, 0.0001f)
        assertEquals(DEFAULT_VOICE_VOLUME, s.voiceVolume, 0.0001f)
    }

    @Test
    fun languageOptionsAreExact() {
        assertEquals(listOf("AUTO", "BENGALI", "HINDI", "ENGLISH"), AppLanguage.entries.map { it.name })
    }

    @Test
    fun personalityOptionsAreExact() {
        assertEquals(
            listOf("NORMAL", "FRIENDLY", "FUNNY", "TEACHER", "DEVELOPER", "PROFESSIONAL"),
            Personality.entries.map { it.name }
        )
    }

    @Test
    fun defaultVoiceIsFemaleAndOnlyFemaleVoicesOffered() {
        assertTrue(FEMALE_VOICES.any { it.id == DEFAULT_VOICE_NAME })
        assertTrue(FEMALE_VOICES.all { it.label.startsWith("Female") })
    }

    @Test
    fun unknownStoredNamesFallBackToDefaults() {
        assertEquals(AppLanguage.AUTO, AppLanguage.fromName("KLINGON"))
        assertEquals(AppLanguage.AUTO, AppLanguage.fromName(null))
        assertEquals(Personality.NORMAL, Personality.fromName("UNKNOWN"))
        assertEquals(ThemeMode.SYSTEM, ThemeMode.fromName(null))
    }

    @Test
    fun sanitizedTrimsNamesAndClampsRanges() {
        val s = NovaSettings(
            assistantName = "   ",
            username = "  Ayesha  ",
            voiceName = "male_unknown",
            speechSpeed = 9f,
            voiceVolume = -1f
        ).sanitized()

        assertEquals("FEHA", s.assistantName)
        assertEquals("Ayesha", s.username)
        assertEquals(DEFAULT_VOICE_NAME, s.voiceName)
        assertEquals(MAX_SPEECH_SPEED, s.speechSpeed, 0.0001f)
        assertEquals(0f, s.voiceVolume, 0.0001f)
    }
}
