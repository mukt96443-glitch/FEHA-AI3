package com.feha.ai.settings.keys

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ApiKeyFormatTest {

    @Test
    fun normalizeTrimsWhitespace() {
        assertEquals("abc123", ApiKeyFormat.normalize("  abc123\n"))
    }

    @Test
    fun plausibilityRejectsBlankAndInternalWhitespace() {
        assertFalse(ApiKeyFormat.isPlausible(""))
        assertFalse(ApiKeyFormat.isPlausible("abc def"))
        assertTrue(ApiKeyFormat.isPlausible("gsk_example1234"))
    }

    @Test
    fun maskShowsOnlyLastFourCharacters() {
        assertEquals("****1234", ApiKeyFormat.mask("AIzaSecret1234"))
    }

    @Test
    fun maskHidesShortKeysCompletely() {
        assertEquals("****", ApiKeyFormat.mask("abc"))
        assertEquals("****", ApiKeyFormat.mask("abcd"))
    }

    @Test
    fun maskOfMissingKeyIsEmpty() {
        assertEquals("", ApiKeyFormat.mask(null))
        assertEquals("", ApiKeyFormat.mask("   "))
    }
}
