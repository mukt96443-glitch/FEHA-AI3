package com.feha.ai.settings.model

import com.feha.ai.core.AssistantBrand

const val MAX_NAME_LENGTH = 32
const val MIN_SPEECH_SPEED = 0.5f
const val MAX_SPEECH_SPEED = 2.0f
const val DEFAULT_SPEECH_SPEED = 1.0f
const val DEFAULT_VOICE_VOLUME = 0.8f

data class VoiceOption(val id: String, val label: String)

/** Female voices only, per the female voice preference. The voice engine is not implemented yet. */
val FEMALE_VOICES: List<VoiceOption> = listOf(
    VoiceOption("female_default", "Female (default)"),
    VoiceOption("female_clear", "Female (clear)"),
    VoiceOption("female_warm", "Female (warm)")
)

val DEFAULT_VOICE_NAME: String = FEMALE_VOICES.first().id

enum class AppLanguage(val displayName: String) {
    AUTO("Auto"),
    BENGALI("Bengali"),
    HINDI("Hindi"),
    ENGLISH("English");

    companion object {
        fun fromName(name: String?): AppLanguage = entries.firstOrNull { it.name == name } ?: AUTO
    }
}

enum class Personality(val displayName: String) {
    NORMAL("Normal"),
    FRIENDLY("Friendly"),
    FUNNY("Funny"),
    TEACHER("Teacher"),
    DEVELOPER("Developer"),
    PROFESSIONAL("Professional");

    companion object {
        fun fromName(name: String?): Personality = entries.firstOrNull { it.name == name } ?: NORMAL
    }
}

enum class ThemeMode(val displayName: String) {
    SYSTEM("System"),
    LIGHT("Light"),
    DARK("Dark");

    companion object {
        fun fromName(name: String?): ThemeMode = entries.firstOrNull { it.name == name } ?: SYSTEM
    }
}

/** All non-secret settings. API keys are deliberately NOT part of this model. */
data class NovaSettings(
    val assistantName: String = AssistantBrand.NAME,
    val username: String = "",
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val personality: Personality = Personality.NORMAL,
    val language: AppLanguage = AppLanguage.AUTO,
    val voiceName: String = DEFAULT_VOICE_NAME,
    val speechSpeed: Float = DEFAULT_SPEECH_SPEED,
    val voiceVolume: Float = DEFAULT_VOICE_VOLUME
) {
    fun sanitized(): NovaSettings = copy(
        assistantName = assistantName.trim().take(MAX_NAME_LENGTH).ifEmpty { AssistantBrand.NAME },
        username = username.trim().take(MAX_NAME_LENGTH),
        voiceName = if (FEMALE_VOICES.any { it.id == voiceName }) voiceName else DEFAULT_VOICE_NAME,
        speechSpeed = if (speechSpeed.isNaN()) DEFAULT_SPEECH_SPEED
        else speechSpeed.coerceIn(MIN_SPEECH_SPEED, MAX_SPEECH_SPEED),
        voiceVolume = if (voiceVolume.isNaN()) DEFAULT_VOICE_VOLUME
        else voiceVolume.coerceIn(0f, 1f)
    )
}
