package com.feha.ai.settings.keys

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * API keys encrypted at rest with an AES256-GCM master key in the Android Keystore.
 *
 * The Keystore is touched only on first key access, never during app startup.
 * If the Keystore or encrypted preferences cannot be opened, every operation
 * fails soft (null or false) and the app keeps running. Key values are never logged;
 * only exception type names are logged.
 */
class EncryptedApiKeyStore(context: Context) : ApiKeyStore {

    private val appContext = context.applicationContext

    private val prefs: SharedPreferences? by lazy { openEncryptedPrefsOrNull() }

    private fun openEncryptedPrefsOrNull(): SharedPreferences? = try {
        val masterKey = MasterKey.Builder(appContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            appContext,
            FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        Log.w(TAG, "Secure key store unavailable: ${e.javaClass.simpleName}")
        null
    }

    override fun getKey(provider: ApiProvider): String? = try {
        prefs?.getString(provider.prefKey, null)?.takeIf { it.isNotBlank() }
    } catch (e: Exception) {
        Log.w(TAG, "Secure key read failed: ${e.javaClass.simpleName}")
        null
    }

    override fun saveKey(provider: ApiProvider, key: String): Boolean = try {
        prefs?.edit()?.putString(provider.prefKey, ApiKeyFormat.normalize(key))?.commit() == true
    } catch (e: Exception) {
        Log.w(TAG, "Secure key write failed: ${e.javaClass.simpleName}")
        false
    }

    override fun clearKey(provider: ApiProvider): Boolean = try {
        prefs?.edit()?.remove(provider.prefKey)?.commit() == true
    } catch (e: Exception) {
        Log.w(TAG, "Secure key clear failed: ${e.javaClass.simpleName}")
        false
    }

    private companion object {
        const val FILE_NAME = "feha_secure_api_keys"
        const val TAG = "FehaKeyStore"
    }
}
