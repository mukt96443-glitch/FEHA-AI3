package com.feha.ai.state

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import com.feha.ai.settings.keys.ApiProvider
import com.feha.ai.settings.model.NovaSettings
import com.feha.ai.settings.repository.KeySaveResult
import com.feha.ai.settings.repository.PersonalityRepository
import com.feha.ai.voice.VoiceSessionHook
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

enum class AppScreen { HOME, SETTINGS }

enum class SettingsStatus {
    PROFILE_SAVED,
    GEMINI_KEY_SAVED,
    GROQ_KEY_SAVED,
    GEMINI_KEY_INVALID,
    GROQ_KEY_INVALID,
    GEMINI_KEY_CLEARED,
    GROQ_KEY_CLEARED,
    SECURE_STORAGE_UNAVAILABLE,
    STORAGE_ERROR
}

/**
 * Compose state holder. Persistence goes through [PersonalityRepository].
 * Startup reads only settings. Secure key storage is read when Settings opens.
 * Every background job runs through [launchSafely], so a storage failure becomes
 * a status message and never an uncaught exception.
 */
@Stable
class NovaAppState(
    private val repository: PersonalityRepository,
    private val scope: CoroutineScope,
    private val voiceSessionHook: VoiceSessionHook
) {
    var settings: NovaSettings by mutableStateOf(NovaSettings())
        private set

    var isLoaded: Boolean by mutableStateOf(false)
        private set

    var currentScreen: AppScreen by mutableStateOf(AppScreen.HOME)
        private set

    /** Masked key previews only (for example "****1234"). Raw keys never enter state. */
    var maskedKeys: Map<ApiProvider, String> by mutableStateOf(emptyMap())
        private set

    var statusMessage: SettingsStatus? by mutableStateOf(null)
        private set

    init {
        launchSafely {
            repository.settings.collect { loaded ->
                settings = loaded
                isLoaded = true
                voiceSessionHook.onSettingsApplied(loaded)
            }
        }
    }

    fun navigate(screen: AppScreen) {
        currentScreen = screen
        if (screen == AppScreen.SETTINGS) {
            launchSafely { refreshMaskedKeys() }
        }
    }

    fun updateSettings(transform: (NovaSettings) -> NovaSettings) {
        launchSafely { repository.updateSettings(transform) }
    }

    fun saveProfile(assistantName: String, username: String) {
        launchSafely {
            repository.updateSettings { it.copy(assistantName = assistantName, username = username) }
            statusMessage = SettingsStatus.PROFILE_SAVED
        }
    }

    fun saveApiKey(provider: ApiProvider, rawKey: String) {
        launchSafely {
            val result = repository.saveApiKey(provider, rawKey)
            refreshMaskedKeys()
            statusMessage = when (result) {
                KeySaveResult.SAVED -> savedStatus(provider)
                KeySaveResult.INVALID_FORMAT -> invalidStatus(provider)
                KeySaveResult.STORAGE_UNAVAILABLE -> SettingsStatus.SECURE_STORAGE_UNAVAILABLE
            }
        }
    }

    fun clearApiKey(provider: ApiProvider) {
        launchSafely {
            val cleared = repository.clearApiKey(provider)
            refreshMaskedKeys()
            statusMessage = if (cleared) clearedStatus(provider) else SettingsStatus.SECURE_STORAGE_UNAVAILABLE
        }
    }

    fun dismissStatus() {
        statusMessage = null
    }

    private fun launchSafely(block: suspend () -> Unit) {
        scope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                statusMessage = SettingsStatus.STORAGE_ERROR
            }
        }
    }

    private suspend fun refreshMaskedKeys() {
        maskedKeys = ApiProvider.entries.associateWith { repository.maskedApiKey(it) }
    }

    private fun savedStatus(provider: ApiProvider): SettingsStatus = when (provider) {
        ApiProvider.GEMINI -> SettingsStatus.GEMINI_KEY_SAVED
        ApiProvider.GROQ -> SettingsStatus.GROQ_KEY_SAVED
    }

    private fun invalidStatus(provider: ApiProvider): SettingsStatus = when (provider) {
        ApiProvider.GEMINI -> SettingsStatus.GEMINI_KEY_INVALID
        ApiProvider.GROQ -> SettingsStatus.GROQ_KEY_INVALID
    }

    private fun clearedStatus(provider: ApiProvider): SettingsStatus = when (provider) {
        ApiProvider.GEMINI -> SettingsStatus.GEMINI_KEY_CLEARED
        ApiProvider.GROQ -> SettingsStatus.GROQ_KEY_CLEARED
    }
}

@Composable
fun rememberNovaAppState(
    repository: PersonalityRepository,
    voiceSessionHook: VoiceSessionHook
): NovaAppState {
    val scope = rememberCoroutineScope()
    return remember(repository, voiceSessionHook) {
        NovaAppState(repository, scope, voiceSessionHook)
    }
}
