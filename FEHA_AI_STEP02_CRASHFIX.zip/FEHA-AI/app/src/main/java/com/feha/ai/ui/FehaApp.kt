package com.feha.ai.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.feha.ai.state.AppScreen
import com.feha.ai.state.NovaAppState
import com.feha.ai.ui.settings.SettingsScreen

@Composable
fun FehaApp(state: NovaAppState) {
    BackHandler(enabled = state.currentScreen == AppScreen.SETTINGS) {
        state.navigate(AppScreen.HOME)
    }

    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
        if (state.isLoaded) {
            when (state.currentScreen) {
                AppScreen.HOME -> HomeScreen(
                    settings = state.settings,
                    onOpenSettings = { state.navigate(AppScreen.SETTINGS) },
                    modifier = Modifier.padding(innerPadding)
                )
                AppScreen.SETTINGS -> SettingsScreen(
                    state = state,
                    onBack = { state.navigate(AppScreen.HOME) },
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
    }
}
