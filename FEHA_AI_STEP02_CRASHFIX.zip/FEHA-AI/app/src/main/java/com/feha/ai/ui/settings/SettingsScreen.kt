package com.feha.ai.ui.settings

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.feha.ai.R
import com.feha.ai.core.AppDistribution
import com.feha.ai.settings.keys.ApiProvider
import com.feha.ai.settings.model.AppLanguage
import com.feha.ai.settings.model.FEMALE_VOICES
import com.feha.ai.settings.model.MAX_SPEECH_SPEED
import com.feha.ai.settings.model.MIN_SPEECH_SPEED
import com.feha.ai.settings.model.Personality
import com.feha.ai.settings.model.ThemeMode
import com.feha.ai.state.NovaAppState
import com.feha.ai.state.SettingsStatus
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    state: NovaAppState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val settings = state.settings

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text(stringResource(R.string.back)) }
            Text(
                text = stringResource(R.string.settings_title),
                style = MaterialTheme.typography.headlineSmall
            )
        }

        state.statusMessage?.let { status ->
            Text(
                text = stringResource(status.messageRes()),
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }

        SectionTitle(R.string.section_profile)
        var assistantNameDraft by remember(settings.assistantName) { mutableStateOf(settings.assistantName) }
        var usernameDraft by remember(settings.username) { mutableStateOf(settings.username) }
        OutlinedTextField(
            value = assistantNameDraft,
            onValueChange = { assistantNameDraft = it },
            label = { Text(stringResource(R.string.field_assistant_name)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = usernameDraft,
            onValueChange = { usernameDraft = it },
            label = { Text(stringResource(R.string.field_username)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { state.saveProfile(assistantNameDraft, usernameDraft) },
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text(stringResource(R.string.save_profile))
        }

        SectionTitle(R.string.section_api_keys)
        ApiKeyEditor(
            provider = ApiProvider.GEMINI,
            maskedKey = state.maskedKeys[ApiProvider.GEMINI].orEmpty(),
            onSave = { state.saveApiKey(ApiProvider.GEMINI, it) },
            onClear = { state.clearApiKey(ApiProvider.GEMINI) }
        )
        Spacer(modifier = Modifier.height(16.dp))
        ApiKeyEditor(
            provider = ApiProvider.GROQ,
            maskedKey = state.maskedKeys[ApiProvider.GROQ].orEmpty(),
            onSave = { state.saveApiKey(ApiProvider.GROQ, it) },
            onClear = { state.clearApiKey(ApiProvider.GROQ) }
        )

        SectionTitle(R.string.section_theme)
        OptionGroup(
            options = ThemeMode.entries,
            selected = settings.themeMode,
            label = { it.displayName },
            onSelect = { mode -> state.updateSettings { it.copy(themeMode = mode) } }
        )

        SectionTitle(R.string.section_personality)
        OptionGroup(
            options = Personality.entries,
            selected = settings.personality,
            label = { it.displayName },
            onSelect = { value -> state.updateSettings { it.copy(personality = value) } }
        )

        SectionTitle(R.string.section_language)
        OptionGroup(
            options = AppLanguage.entries,
            selected = settings.language,
            label = { it.displayName },
            onSelect = { value -> state.updateSettings { it.copy(language = value) } }
        )

        SectionTitle(R.string.section_voice)
        OptionGroup(
            options = FEMALE_VOICES,
            selected = FEMALE_VOICES.firstOrNull { it.id == settings.voiceName } ?: FEMALE_VOICES.first(),
            label = { it.label },
            onSelect = { voice -> state.updateSettings { it.copy(voiceName = voice.id) } }
        )

        SectionTitle(R.string.section_speed)
        var speed by remember(settings.speechSpeed) { mutableFloatStateOf(settings.speechSpeed) }
        Text(text = stringResource(R.string.value_speed, speed))
        Slider(
            value = speed,
            onValueChange = { speed = it },
            onValueChangeFinished = {
                state.updateSettings { it.copy(speechSpeed = speed) }
            },
            valueRange = MIN_SPEECH_SPEED..MAX_SPEECH_SPEED
        )

        SectionTitle(R.string.section_volume)
        var volume by remember(settings.voiceVolume) { mutableFloatStateOf(settings.voiceVolume) }
        Text(text = stringResource(R.string.value_volume, (volume * 100).roundToInt()))
        Slider(
            value = volume,
            onValueChange = { volume = it },
            onValueChangeFinished = {
                state.updateSettings { it.copy(voiceVolume = volume) }
            },
            valueRange = 0f..1f
        )

        Text(
            text = stringResource(R.string.about_build, AppDistribution.channel),
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 24.dp)
        )
    }
}

@Composable
private fun SectionTitle(@StringRes titleRes: Int) {
    Text(
        text = stringResource(titleRes),
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 20.dp, bottom = 8.dp)
    )
}

@Composable
private fun ApiKeyEditor(
    provider: ApiProvider,
    maskedKey: String,
    onSave: (String) -> Unit,
    onClear: () -> Unit
) {
    // Draft is held in memory only. It is not saved in rememberSaveable and is never logged.
    var draft by remember(provider) { mutableStateOf("") }

    Text(
        text = stringResource(R.string.api_key_title, provider.label),
        style = MaterialTheme.typography.titleSmall
    )
    Text(
        text = if (maskedKey.isEmpty()) {
            stringResource(R.string.api_key_none)
        } else {
            stringResource(R.string.api_key_saved, maskedKey)
        },
        style = MaterialTheme.typography.bodySmall
    )
    OutlinedTextField(
        value = draft,
        onValueChange = { draft = it },
        label = { Text(stringResource(R.string.field_api_key)) },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        modifier = Modifier.fillMaxWidth()
    )
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(vertical = 8.dp)
    ) {
        Button(
            onClick = {
                onSave(draft)
                draft = ""
            },
            enabled = draft.isNotBlank()
        ) {
            Text(stringResource(R.string.save_key))
        }
        OutlinedButton(
            onClick = onClear,
            enabled = maskedKey.isNotEmpty()
        ) {
            Text(stringResource(R.string.clear_key))
        }
    }
}

@Composable
private fun <T> OptionGroup(
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit
) {
    Column {
        options.forEach { option ->
            val isSelected = option == selected
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .selectable(
                        selected = isSelected,
                        role = Role.RadioButton,
                        onClick = { onSelect(option) }
                    )
                    .padding(vertical = 4.dp)
            ) {
                RadioButton(selected = isSelected, onClick = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = label(option))
            }
        }
    }
}

@StringRes
private fun SettingsStatus.messageRes(): Int = when (this) {
    SettingsStatus.PROFILE_SAVED -> R.string.status_profile_saved
    SettingsStatus.GEMINI_KEY_SAVED -> R.string.status_gemini_key_saved
    SettingsStatus.GROQ_KEY_SAVED -> R.string.status_groq_key_saved
    SettingsStatus.GEMINI_KEY_INVALID -> R.string.status_gemini_key_invalid
    SettingsStatus.GROQ_KEY_INVALID -> R.string.status_groq_key_invalid
    SettingsStatus.GEMINI_KEY_CLEARED -> R.string.status_gemini_key_cleared
    SettingsStatus.GROQ_KEY_CLEARED -> R.string.status_groq_key_cleared
    SettingsStatus.SECURE_STORAGE_UNAVAILABLE -> R.string.status_secure_storage_unavailable
    SettingsStatus.STORAGE_ERROR -> R.string.status_storage_error
}
