package com.feha.ai

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.core.ReplaceFileCorruptionHandler
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.preferencesDataStore
import com.feha.ai.settings.keys.ApiKeyStore
import com.feha.ai.settings.keys.EncryptedApiKeyStore
import com.feha.ai.settings.repository.PersonalityRepository
import com.feha.ai.settings.storage.NovaPreferences
import com.feha.ai.voice.VoiceSessionManager

/** A corrupt settings file resets to defaults instead of failing every read. */
private val Context.novaSettingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "nova_settings",
    corruptionHandler = ReplaceFileCorruptionHandler { _ -> emptyPreferences() }
)

/** Manual dependency container. Everything is created lazily, once per process. */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val apiKeyStore: ApiKeyStore by lazy { EncryptedApiKeyStore(appContext) }
    val novaPreferences: NovaPreferences by lazy { NovaPreferences(appContext.novaSettingsDataStore) }
    val personalityRepository: PersonalityRepository by lazy {
        PersonalityRepository(novaPreferences, apiKeyStore)
    }
    val voiceSessionManager: VoiceSessionManager by lazy { VoiceSessionManager() }
}
