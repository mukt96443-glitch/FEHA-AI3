package com.feha.ai.core

import com.feha.ai.BuildConfig

/** Build channel chosen by the product flavor: "direct" or "play". */
object AppDistribution {
    val channel: String
        get() = BuildConfig.DISTRIBUTION_CHANNEL
}
